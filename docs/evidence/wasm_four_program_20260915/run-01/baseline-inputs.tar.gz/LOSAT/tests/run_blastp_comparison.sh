#!/bin/bash

set -euo pipefail

# NCBI reference: ncbi-blast/c++/src/algo/blast/blastinput/cmdline_flags.cpp:46-94
# ```c
# const string kArgQuery("query");
# const string kArgOutput("out");
# const string kArgSubject("subject");
# const string kArgNumThreads("num_threads");
# const string kArgEvalue("evalue");
# const string kArgMaxTargetSequences("max_target_seqs");
# ```
#
# NCBI reference: ncbi-blast/c++/src/algo/blast/blastinput/blast_args.cpp:2657-2660
# ```c
# arg_desc.AddDefaultKey(kArgOutputFormat, "format",
#                        kOutputFormatDescription,
#                        CArgDescriptions::eString,
#                        NStr::IntToString(dft_outfmt));
# ```

LOSAT_BIN="../target/debug/LOSAT"
REF_DIR="./blast_out/blastp"
FASTA_DIR="./fasta"
source ./blastp_parity_options.sh

# NCBI reference: ncbi-blast/c++/src/algo/blast/blastinput/cmdline_flags.cpp:46-94
# ```c
# const string kArgOutput("out");
# ```
#
# Comparison-harness note: keep LOSAT outputs in a temporary directory so
# tracked `losat_out/` artifacts cannot mask current-source divergence.
OUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/losat-blastp-XXXXXX")"
trap 'rm -rf "${OUT_DIR}"' EXIT

run_case() {
    local query="$1"
    local subject="$2"
    local stem="$3"

    "${LOSAT_BIN}" blastp \
        -query "${FASTA_DIR}/${query}" \
        -subject "${FASTA_DIR}/${subject}" \
        -outfmt 6 \
        "${BLASTP_PARITY_STRICT_OPTIONS[@]}" \
        -out "${OUT_DIR}/${stem}.out" \
        > "${OUT_DIR}/${stem}.log" 2>&1

    # NCBI reference: ncbi-blast/c++/src/objtools/align_format/tabular.cpp:1106-1108
    # ```c
    #     x_PrintField(*iter);
    # }
    # m_Ostream << "\n";
    # ```
    # The parity assertion is on tabular fields; ignore fixture CRLF storage.
    diff -u --strip-trailing-cr "${REF_DIR}/${stem}.out" "${OUT_DIR}/${stem}.out"
}

run_case "WSSV.faa" "PajaWSV.faa" "WSSV.PajaWSV.blastp"
run_case "PajaWSV.faa" "SicyWSV.faa" "PajaWSV.SicyWSV.blastp"
run_case "WSSV.faa" "SicyWSV.faa" "WSSV.SicyWSV.blastp"
run_case "WSSV.faa" "CoBV.faa" "WSSV.CoBV.blastp"
run_case "CoBV.faa" "PajaWSV.faa" "CoBV.PajaWSV.blastp"
run_case "CoBV.faa" "SicyWSV.faa" "CoBV.SicyWSV.blastp"
run_case "AP027078.faa" "AP027131.faa" "AP027078.AP027131.blastp"
run_case "AP027078.faa" "AP027132.faa" "AP027078.AP027132.blastp"
run_case "AP027078.faa" "AP027133.faa" "AP027078.AP027133.blastp"
run_case "AP027078.faa" "NZ_CP006932.faa" "AP027078.NZ_CP006932.blastp"
run_case "AP027131.faa" "AP027132.faa" "AP027131.AP027132.blastp"
run_case "AP027131.faa" "AP027133.faa" "AP027131.AP027133.blastp"
run_case "AP027131.faa" "NZ_CP006932.faa" "AP027131.NZ_CP006932.blastp"
run_case "AP027132.faa" "AP027133.faa" "AP027132.AP027133.blastp"
run_case "AP027132.faa" "NZ_CP006932.faa" "AP027132.NZ_CP006932.blastp"
run_case "AP027133.faa" "NZ_CP006932.faa" "AP027133.NZ_CP006932.blastp"
