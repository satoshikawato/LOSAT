"""Gate negatives; no algorithm emulation or replacement expected output.

NCBI c++/src/objtools/align_format/tabular.cpp:1098-1108:
  x_PrintField(*iter); ... m_Ostream << "\n";
NCBI c++/src/algo/blast/format/blast_format.cpp:794-808:
  dbname = string("User specified sequence set (Input: ") + m_SubjectTag ...;
Synthetic subprocesses exercise the harness only, never certify a search.
"""

import hashlib
import json
from types import SimpleNamespace
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

import wasm_performance as perf
import summarize_wasm_performance as summary


class GateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)

    def gate(self, expected, observed):
        return perf.raw_gate(
            {
                "status": "PASS",
                "raw_output_sha256": hashlib.sha256(observed).hexdigest(),
            },
            hashlib.sha256(expected).hexdigest(),
        )

    def test_exporter_rejects_failure_after_successful_warmup(self):
        status, failed, median = summary.series_result(
            [{"status": "PASS"}, {"status": "TIMEOUT", "output": "failed.txt"}],
            {"warmup_count": 1, "timed_repetitions": 5},
        )
        self.assertEqual(status, "TIMEOUT")
        self.assertEqual(failed["output"], "failed.txt")
        self.assertIsNone(median)

    def test_exporter_requires_complete_series(self):
        status, _, median = summary.series_result(
            [{"status": "PASS"}],
            {"warmup_count": 1, "timed_repetitions": 5},
        )
        self.assertEqual(status, "NOT_RUN")
        self.assertIsNone(median)

    def test_exporter_median_excludes_warmup_and_diagnostic(self):
        rows = [
            {
                "status": "PASS",
                "repeat": i,
                "timed": 1 <= i < 6,
                "diagnostics_enabled": i == 6,
                "wall_seconds": seconds,
                "peak_rss_bytes": None,
            }
            for i, seconds in enumerate([999, 5, 1, 3, 4, 2, 888])
        ]
        status, _, median = summary.series_result(
            rows, {"warmup_count": 1, "timed_repetitions": 5}
        )
        self.assertEqual(status, "PASS")
        self.assertEqual(median["median_seconds"], 3)
        self.assertIsNone(median["peak_rss_bytes"])

    # NCBI c++/src/algo/blast/api/prelim_stage.cpp:178-188:
    # (*thread)->Join(&result);
    # Synthetic exact bytes isolate timing admission from the independent raw gate.
    def test_clock_consistency_gates_cold_warm_but_preserves_raw_audit(self):
        for phase, consistent in [("benchmark", False), ("benchmark", True),
                                  ("warm", False), ("warm", True), ("audit", False)]:
            with self.subTest(phase=phase, consistent=consistent):
                directory = self.root / f"{phase}-{consistent}"
                directory.mkdir()
                output = directory / "exact.out"
                output.write_bytes(b"synthetic exact bytes\n")
                (directory / "stderr.txt").write_text("")
                expected = hashlib.sha256(output.read_bytes()).hexdigest()
                case = {"program": "blastn", "case_id": "synthetic", "focus": {"benchmark": "true"},
                        "serial_applicable": True, "classification": "EXACT_TEXT",
                        "losat_sha256": expected, "oracle_argv": ["oracle"]}
                manifest = {"cases": [case], "cwd": str(directory),
                            "measurement": {"host_cap": 1, "thread_matrix": [1], "timeout_seconds": 1,
                                            "warmup_count": 1, "timed_repetitions": 5,
                                            "memory_budget_bytes": 10000, "boundary": "synthetic"},
                            "runtime": {"node": "node", "flags": [], "runners": {"warm_serial": "warm"}},
                            "artifacts": {"serial": {"path": "synthetic.wasm"}}}
                manifest_path = directory / "manifest.json"
                manifest_path.write_text(json.dumps(manifest))
                args = SimpleNamespace(phase=phase, threads=None if phase == "audit" else [1],
                                       targets=["serial"], case=None, manifest=manifest_path,
                                       output=directory / "results")
                result = {"status": "PASS", "exit_status": 0, "output": str(output),
                          "raw_output_sha256": expected, "raw_output_bytes": output.stat().st_size,
                          "peak_rss_bytes": 1, "wall_seconds": 1,
                          "monotonic_clock_agreement": consistent, "realtime_clock_agreement": False}
                warm = directory / "warm.json"
                warm.write_text(json.dumps({"compile_seconds": 0.1, "samples": [
                    {"repeat": i, "output": str(output), "exit_status": 0,
                     "wall_seconds": i + 1, "process_lifetime_peak_rss_bytes": 1}
                    for i in range(6)]}))

                def execute(argv, *unused):
                    if argv == ["oracle"]:
                        return {**result, "monotonic_clock_agreement": True}
                    return {**result, "output": str(warm) if phase == "warm" else str(output)}

                with mock.patch.object(perf, "preflight"), \
                     mock.patch.object(perf, "execute", side_effect=execute), \
                     mock.patch.object(perf, "thread_command", return_value=["node", "runner", "synthetic.wasm", "-num_threads", "1", "-out", "unused"]), \
                     mock.patch.object(perf, "oracle_contract", return_value="PASS"), \
                     mock.patch.object(perf, "validate_thread_evidence", return_value={}):
                    code = perf.run(args)
                report = json.loads((args.output / "summary.json").read_text())
                rows = [json.loads(line) for line in (args.output / "samples.jsonl").read_text().splitlines()]
                accepted = consistent or phase == "audit"
                self.assertEqual(code, 0 if accepted else 1)
                self.assertTrue(all(row["status"] == ("PASS" if accepted else "CLOCK_INCONSISTENT") for row in rows))
                self.assertEqual(bool(report["medians"]), consistent and phase != "audit")
                if phase == "audit":
                    self.assertEqual(rows[0]["canonical_gate"], "PASS")
                elif not consistent:
                    self.assertTrue(all(row["monotonic_clock_agreement"] is False for row in rows))

    def test_wrong_hash(self):
        path = self.root / "artifact"
        path.write_bytes(b"wrong")
        with self.assertRaises(perf.GateFailure):
            perf.checked_file(path, "0" * 64)

    def test_missing_artifact_and_oracle(self):
        for name in ("artifact.wasm", "blastn"):
            with self.assertRaises(perf.GateFailure):
                perf.checked_file(self.root / name, "0" * 64)

    def test_header_path_is_not_normalized(self):
        self.assertEqual(
            self.gate(b"# Subject: /fixed/input\na\n", b"# Subject: /other/input\na\n"),
            "BASELINE_PARITY_FAIL",
        )

    def test_pairwise_header_is_not_normalized(self):
        self.assertEqual(
            self.gate(b"BLASTP 2.17.0+\nQuery= x\n", b"BLASTP 2.16.0+\nQuery= x\n"),
            "BASELINE_PARITY_FAIL",
        )

    def test_order_and_newlines_are_normative(self):
        for data in (b"b\na\n", b"a\r\nb\r\n"):
            self.assertEqual(self.gate(b"a\nb\n", data), "BASELINE_PARITY_FAIL")

    def test_serial_threaded_mislabel(self):
        serial = {"imports": [], "exports": [{"name": "_start"}]}
        threaded = {
            "imports": [{"module": "wasi", "name": "thread-spawn"}],
            "exports": [{"name": "_start"}, {"name": "wasi_thread_start"}],
        }
        with self.assertRaises(perf.GateFailure):
            perf.validate_kind("threaded", serial)
        with self.assertRaises(perf.GateFailure):
            perf.validate_kind("serial", threaded)
        perf.validate_kind("serial", serial)
        perf.validate_kind("threaded", threaded)

    def test_library_is_not_command(self):
        with self.assertRaises(perf.GateFailure):
            perf.validate_kind(
                "serial", {"imports": [], "exports": [{"name": "run_pair"}]}
            )

    def execute(self, script, timeout=5):
        return perf.execute(
            [sys.executable, "-c", script, "-out", "unused"],
            self.root,
            self.root / "run",
            os.environ.copy(),
            timeout,
        )

    def test_bad_exit_even_with_expected_output(self):
        result = self.execute(
            "import pathlib,sys;pathlib.Path(sys.argv[-1]).write_bytes(b'');sys.exit(7)"
        )
        self.assertEqual(result["status"], "BAD_EXIT")
        # NCBI reference: c++/src/algo/blast/api/prelim_stage.cpp:178-188
        # (*thread)->Join(&result);
        # Exact recorded endpoints cover the same process lifetime on failure.
        self.assertGreater(result["monotonic_end"], result["monotonic_start"])
        self.assertEqual(result["wall_seconds"], result["monotonic_end"] - result["monotonic_start"])
        self.assertEqual(
            perf.raw_gate(result, hashlib.sha256(b"").hexdigest()), "BAD_EXIT"
        )

    def test_missing_output(self):
        self.assertEqual(self.execute("pass")["status"], "MISSING_OUTPUT")

    def test_timeout_never_zero_time_pass(self):
        result = self.execute("import time;time.sleep(5)", timeout=0.05)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertGreater(result["wall_seconds"], 0)

    # NCBI reference: c++/src/algo/blast/api/prelim_stage.cpp:178-188
    # (*thread)->Join(&result);
    # An early host timer wake must not terminate a search before its deadline.
    def test_early_watchdog_wake_preserves_success_and_cancellation(self):
        timer = perf.threading.Timer
        with mock.patch.object(perf.threading, "Timer", side_effect=lambda interval, callback: timer(0.001, callback)):
            result = self.execute(
                "import time,pathlib,sys;time.sleep(0.08);pathlib.Path(sys.argv[-1]).write_bytes(b'ok')",
                timeout=0.5,
            )
        self.assertEqual(result["status"], "PASS")
        self.assertGreaterEqual(result["watchdog_clocks"]["early_wakeups"], 1)
        self.assertNotIn("fired", result["watchdog_clocks"])

    # NCBI reference: c++/src/algo/blast/api/prelim_stage.cpp:178-188
    # (*thread)->Join(&result);
    # The same early wake still terminates a hung child at the monotonic deadline.
    def test_early_watchdog_wake_still_expires_at_monotonic_deadline(self):
        timer = perf.threading.Timer
        with mock.patch.object(perf.threading, "Timer", side_effect=lambda interval, callback: timer(0.001, callback)):
            result = self.execute("import time;time.sleep(5)", timeout=0.07)
        self.assertEqual(result["status"], "TIMEOUT")
        clocks = result["watchdog_clocks"]
        self.assertGreaterEqual(clocks["fired"]["monotonic"] - clocks["started"]["monotonic"], 0.07)

    def test_default_omission_is_preserved(self):
        catalog = perf.authority.load_catalog(
            perf.ROOT, perf.capture(["git", "rev-parse", "HEAD"])
        )
        case = catalog.blastp_cases["pairwise_default_serial"]
        _, argv = catalog.blastp_audit.build_commands(
            case, Path("oracle"), Path("LOSAT"), self.root
        )
        self.assertNotIn("-max_target_seqs", argv)

    def test_readonly_output_directory(self):
        (self.root / "run").mkdir()
        with self.assertRaises(FileExistsError):
            self.execute("pass")

    def test_sorted_diff_is_diagnostic_only(self):
        a, b = self.root / "a", self.root / "b"
        a.write_bytes(b"a\nb\n")
        b.write_bytes(b"b\na\n")
        perf.diagnostic_diff(a, b, self.root)
        self.assertEqual((self.root / "sorted-diagnostic.diff").read_text(), "")
        self.assertTrue((self.root / "ordered.diff").read_text())
        self.assertEqual(
            self.gate(a.read_bytes(), b.read_bytes()), "BASELINE_PARITY_FAIL"
        )

    def test_manifest_argv_tampering_is_rejected(self):
        # Construct the canonical portion without depending on locally built artifacts.
        head = perf.capture(["git", "rev-parse", "HEAD"])
        catalog = perf.authority.load_catalog(perf.ROOT, head)
        cases = []
        oracles = {p: Path(p) for p in perf.ORACLE_HASHES}
        for row in catalog.canonical_rows:
            ncbi, losat = perf.authority._base_commands(
                perf.ROOT,
                catalog,
                row["program"],
                row["case_id"],
                Path("LOSAT"),
                oracles,
                self.root,
            )
            cases.append(
                {
                    **row,
                    "serial_applicable": row["program"] != "blastp"
                    or catalog.blastp_cases[row["case_id"]].num_threads == 1,
                    "oracle_argv": ncbi,
                    "losat_argv": losat,
                }
            )
        manifest = {
            "schema_version": perf.SCHEMA,
            "cwd": str(perf.ROOT),
            "source": {"head": head},
            "cases": cases,
            "artifacts": {"native": {"path": "LOSAT"}},
            "oracle": {p: {"path": p} for p in oracles},
        }
        case = next(
            c for c in cases if c["case_id"] == "compact.multi_query.no_hit.outfmt7"
        )
        case["losat_argv"] += ["-evalue", "1e-180"]
        with self.assertRaisesRegex(
            perf.GateFailure, "ordered argv authority mismatch"
        ):
            perf.preflight(manifest)


if __name__ == "__main__":
    unittest.main()


# NCBI reference: c++/src/algo/blast/api/prelim_stage.cpp:177-188
# (*thread)->Run(); (*thread)->Join(&result);
class ThreadEvidenceTests(unittest.TestCase):
    def record(self):
        import json
        lines = ["[losat-thread-pool] program=blastn requested_threads=2 pool_threads=2 caller_participates=true",
                 "[losat-thread-stage] program=blastn stage=subjects work_items=1 parallel_selected=false",
                 "[losat-thread-stage] program=blastn stage=dp_traceback work_items=8 parallel_selected=true"]
        for event in ["spawn_attempt", "spawned", "ready", "exited"]:
            for tid in [1]:
                lines.append("[losat-wasi-event] " + json.dumps(dict(event=event, tid=tid, code=0)))
        return "\n".join(lines)

    def test_serial_subject_stage_does_not_shrink_dp_pool(self):
        value = perf.validate_thread_evidence(self.record(), 2, "threaded")
        self.assertEqual(value["pool_threads"], 2)
        self.assertEqual(value["host_worker_counts"]["ready"], 1)

    def test_missing_or_contradictory_worker_events_fail(self):
        for bad in [self.record().replace('"ready"', '"missing"', 1),
                    self.record().replace('caller_participates=true', 'caller_participates=false'),
                    self.record().replace('"code": 0', '"code": 1'),
                    self.record().replace('pool_threads=2', 'pool_threads=1'),
                    'effective_threads=2 parallel=false']:
            with self.assertRaises(perf.GateFailure):
                perf.validate_thread_evidence(bad, 2, "threaded")
