//! BLAST Input Handling
//!
//! Reference: ncbi-blast/c++/src/algo/blast/blastinput/
//!
//! This module provides input handling for BLAST searches
//! including argument parsing and FASTA input processing.
//!
//! # Structure
//!
//! - `blast_args` - Common argument handling
//! - `blastn_args` - BLASTN-specific arguments
//! - `blastp_args` - BLASTP-specific arguments
//! - `tblastx_args` - TBLASTX-specific arguments

pub mod blast_args;
pub mod blastn_args;
pub mod blastp_args;
pub mod tblastx_args;

// NCBI blastinput/blast_args.cpp:332-349: shared string-valued filtering arguments.
pub mod value_parsers;
